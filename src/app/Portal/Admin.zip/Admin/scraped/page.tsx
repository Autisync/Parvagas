"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { authFetch } from "@/lib/api";
import { fetchScraped, statusBadgeClass, toDateLabel, type ScrapedRecord, type Pagination } from "../adminClient";
import { AdminAlert, AdminEmptyState, AdminFilterBar, AdminPageHeader, adminFieldClass } from "../components/AdminUI";
import PaginationControls from "../components/PaginationControls";

export default function AdminScrapedPage() {
  const { token } = useAuth("admin");
  const [jobs, setJobs] = useState<ScrapedRecord[]>([]);
  const [newTitle, setNewTitle] = useState("");
  const [newCompany, setNewCompany] = useState("");
  const [newLocation, setNewLocation] = useState("");
  const [newSourceUrl, setNewSourceUrl] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("pending");
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<Pagination | undefined>();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!token) return;
    setError("");
    try {
      const res = await fetchScraped(token, { page, limit: 15, keyword: search, status: filter });
      setJobs(res.scrapedJobs || []);
      setPagination(res.pagination);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar scraped jobs.");
    }
  }, [token, page, search, filter]);

  useEffect(() => {
    load();
  }, [load]);

  const createScraped = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!token) return;
    setError("");
    try {
      await authFetch("/admin/scraped-jobs", token, {
        method: "POST",
        body: JSON.stringify({ title: newTitle, company: newCompany, location: newLocation, sourceUrl: newSourceUrl }),
      });
      setNewTitle("");
      setNewCompany("");
      setNewLocation("");
      setNewSourceUrl("");
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao criar scraped job.");
    }
  };

  const review = async (id: string, status: "approved" | "rejected" | "duplicate" | "archived", publishAsPublicJob = false) => {
    if (!token) return;
    const reviewNote = window.prompt("Nota de revisão (opcional):") || "";
    setBusy(id);
    setError("");
    try {
      await authFetch(`/admin/scraped-jobs/${id}/review`, token, {
        method: "PATCH",
        body: JSON.stringify({ status, reviewNote, publishAsPublicJob }),
      });
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao rever scraped job.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div>
      <AdminPageHeader
        eyebrow="Curadoria"
        title="Curadoria de Scraped Jobs"
        description="Controle qualidade de vagas externas e evite duplicados no catálogo."
      />

      <form onSubmit={createScraped} className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="grid gap-3 md:grid-cols-2">
          <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Título" required className={adminFieldClass} />
          <input value={newCompany} onChange={(e) => setNewCompany(e.target.value)} placeholder="Empresa/Fonte" required className={adminFieldClass} />
          <input value={newLocation} onChange={(e) => setNewLocation(e.target.value)} placeholder="Local" className={adminFieldClass} />
          <input value={newSourceUrl} onChange={(e) => setNewSourceUrl(e.target.value)} placeholder="URL de origem" className={adminFieldClass} />
        </div>
        <button type="submit" className="mt-3 rounded-xl bg-red-600 px-3 py-2 text-xs font-semibold text-white">Criar scraped job</button>
      </form>

      <AdminFilterBar>
        <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Pesquisar scraped jobs" className={`${adminFieldClass} md:col-span-2`} />
        <select value={filter} onChange={(e) => { setFilter(e.target.value); setPage(1); }} className={adminFieldClass}>
          <option value="pending">Pendentes</option>
          <option value="approved">Aprovadas</option>
          <option value="rejected">Rejeitadas</option>
          <option value="all">Todas</option>
        </select>
      </AdminFilterBar>

      {error && <AdminAlert>{error}</AdminAlert>}

      <div className="mt-5 grid gap-3">
        {jobs.length === 0 && <AdminEmptyState title="Sem scraped jobs nesta vista" description="Ajuste os filtros ou aguarde a próxima importação." />}
        {jobs.map((job) => {
          const status = String(job.status || "pending");
          return (
            <div key={job._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-slate-900">{job.title || "Vaga importada"}</p>
                  <p className="text-xs text-slate-500">{job.company || "Fonte externa"} · {job.location || "Local"}</p>
                  <p className="text-xs text-slate-400">{toDateLabel(job.createdAt)}</p>
                </div>
                <span className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadgeClass(status)}`}>{status}</span>
              </div>
              {job.duplicateOf && <p className="mt-2 text-xs text-amber-700">Possível duplicado detetado</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                <button disabled={busy === job._id} onClick={() => review(job._id, "approved", true)} className="rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Aprovar + publicar</button>
                <button disabled={busy === job._id} onClick={() => review(job._id, "rejected")} className="rounded-xl bg-rose-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Rejeitar</button>
                <button disabled={busy === job._id} onClick={() => review(job._id, "duplicate")} className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-800 disabled:opacity-50">Marcar duplicado</button>
                <button disabled={busy === job._id} onClick={() => review(job._id, "archived")} className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50">Arquivar</button>
              </div>
            </div>
          );
        })}
      </div>
      <PaginationControls pagination={pagination} onPage={setPage} />
    </div>
  );
}
