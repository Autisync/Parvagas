"use client";

import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import AdminSidebar from "./components/AdminSidebar";
import { fetchAdminMe } from "./adminClient";

export default function AdminLayout({ children }: { children: ReactNode }) {
  const { token, user, loading } = useAuth("admin");
  const fallbackLevel = useMemo(
    () => (user?.adminLevel === "moderator" ? "moderator" : "super-admin"),
    [user?.adminLevel]
  );
  const [level, setLevel] = useState<"super-admin" | "moderator">(fallbackLevel);

  useEffect(() => {
    setLevel(fallbackLevel);
  }, [fallbackLevel]);

  useEffect(() => {
    if (!token) return;
    fetchAdminMe(token)
      .then((me) => setLevel(me.adminLevel))
      .catch(() => {
        // Keep fallback level from local session if /admin/me fails.
      });
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-4 border-red-600 border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-red-600">Parvagas Admin</p>
            <p className="text-sm font-semibold text-slate-900">{level === "super-admin" ? "SuperAdmin Console" : "Moderator Console"}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-700">
              {level}
            </span>
            <Link href="/Login" className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:border-red-200 hover:text-red-700">
              Login público
            </Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[280px,1fr]">
          <AdminSidebar level={level} />
          <section className="min-w-0">{children}</section>
        </div>
      </main>
    </div>
  );
}
