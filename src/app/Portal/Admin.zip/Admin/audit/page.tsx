"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import {
  fetchAdminActions,
  fetchAdminMe,
  fetchAuditLogs,
  toDateLabel,
  type AdminActionRecord,
  type AdminLevel,
  type AuditLogRecord,
  type Pagination,
} from "../adminClient";
import { AdminAlert, AdminEmptyState, AdminFilterBar, AdminPageHeader, AdminRestricted, adminFieldClass } from "../components/AdminUI";
import PaginationControls from "../components/PaginationControls";

type Tab = "audit" | "admin-actions";

export default function AdminAuditPage() {
  const { token } = useAuth("admin");
  const [level, setLevel] = useState<AdminLevel>("super-admin");
  const [tab, setTab] = useState<Tab>("audit");
  const [keyword, setKeyword] = useState("");
  const [action, setAction] = useState("");
  const [resourceType, setResourceType] = useState("");
  const [page, setPage] = useState(1);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [adminActions, setAdminActions] = useState<AdminActionRecord[]>([]);
  const [pagination, setPagination] = useState<Pagination | undefined>();
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!token) return;
    setError("");
    try {
      const me = await fetchAdminMe(token);
      setLevel(me.adminLevel);
      if (me.adminLevel !== "super-admin") return;

      if (tab === "audit") {
        const res = await fetchAuditLogs(token, { page, limit: 20, keyword, action, resourceType });
        setAuditLogs(res.auditLogs || []);
        setPagination(res.pagination);
      } else {
        const res = await fetchAdminActions(token, { page, limit: 20, keyword, action, targetType: resourceType });
        setAdminActions(res.adminActions || []);
        setPagination(res.pagination);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar auditoria.");
    }
  }, [token, tab, page, keyword, action, resourceType]);

  useEffect(() => {
    load();
  }, [load]);

  if (level !== "super-admin") {
    return (
      <AdminRestricted title="Auditoria restrita">
        Apenas super-admin pode consultar logs de ações privilegiadas.
      </AdminRestricted>
    );
  }

  return (
    <div>
      <AdminPageHeader
        eyebrow="Auditoria"
        title="Ações Privilegiadas"
        description="Inspecione alterações sensíveis, moderação, acessos e operações administrativas."
      />

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          onClick={() => { setTab("audit"); setPage(1); }}
          aria-pressed={tab === "audit"}
          className={`rounded-xl border px-4 py-2 text-sm font-semibold shadow-sm transition ${tab === "audit" ? "border-red-200 bg-red-50 text-red-800" : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}
        >
          Audit logs
        </button>
        <button
          onClick={() => { setTab("admin-actions"); setPage(1); }}
          aria-pressed={tab === "admin-actions"}
          className={`rounded-xl border px-4 py-2 text-sm font-semibold shadow-sm transition ${tab === "admin-actions" ? "border-red-200 bg-red-50 text-red-800" : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}
        >
          Admin actions
        </button>
      </div>

      <AdminFilterBar>
        <input value={keyword} onChange={(e) => { setKeyword(e.target.value); setPage(1); }} placeholder="Pesquisar logs" className={adminFieldClass} />
        <input value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} placeholder="Filtrar por ação" className={adminFieldClass} />
        <input value={resourceType} onChange={(e) => { setResourceType(e.target.value); setPage(1); }} placeholder={tab === "audit" ? "Resource type" : "Target type"} className={adminFieldClass} />
      </AdminFilterBar>

      {error && <AdminAlert>{error}</AdminAlert>}

      <div className="mt-5 grid gap-3">
        {tab === "audit" && auditLogs.length === 0 && <AdminEmptyState title="Sem audit logs nesta vista" description="Ajuste os filtros ou aguarde novos eventos." />}
        {tab === "audit" && auditLogs.map((log) => (
          <div key={log._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-slate-900">{log.action || "Ação"}</p>
                <p className="text-xs text-slate-500">{log.resourceType || "Resource"} · {log.resourceId || "sem recurso"} · actor {log.actorUserId || "system"}</p>
                <p className="text-xs text-slate-400">{toDateLabel(log.createdAt)}</p>
              </div>
              <code className="max-w-full overflow-auto rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-700">
                {JSON.stringify(log.details || {})}
              </code>
            </div>
          </div>
        ))}

        {tab === "admin-actions" && adminActions.length === 0 && <AdminEmptyState title="Sem admin actions nesta vista" description="Ajuste os filtros ou aguarde novas ações privilegiadas." />}
        {tab === "admin-actions" && adminActions.map((entry) => (
          <div key={entry._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-slate-900">{entry.action || "Admin action"}</p>
                <p className="text-xs text-slate-500">{entry.targetType || "Target"} · {entry.targetId || "sem alvo"} · admin {entry.adminUserId || "system"}</p>
                <p className="text-xs text-slate-400">{toDateLabel(entry.createdAt)}</p>
              </div>
              <code className="max-w-full overflow-auto rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-700">
                {JSON.stringify(entry.payload || {})}
              </code>
            </div>
          </div>
        ))}
      </div>

      <PaginationControls pagination={pagination} onPage={setPage} />
    </div>
  );
}
