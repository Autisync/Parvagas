"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { authFetch } from "@/lib/api";
import { fetchUsers, fetchAdminMe, statusBadgeClass, toDateLabel, type UserRecord, type AdminLevel, type Pagination } from "../adminClient";
import { AdminAlert, AdminEmptyState, AdminFilterBar, AdminPageHeader, adminFieldClass } from "../components/AdminUI";
import PaginationControls from "../components/PaginationControls";

export default function AdminUsersPage() {
  const { token, user } = useAuth("admin");
  const [list, setList] = useState<UserRecord[]>([]);
  const [search, setSearch] = useState("");
  const [role, setRole] = useState("all");
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<Pagination | undefined>();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [level, setLevel] = useState<AdminLevel>(user?.adminLevel === "moderator" ? "moderator" : "super-admin");

  const load = useCallback(async () => {
    if (!token) return;
    setError("");
    try {
      const [usersRes, me] = await Promise.all([fetchUsers(token, { page, limit: 15, keyword: search, role }), fetchAdminMe(token)]);
      setList(usersRes.users || []);
      setPagination(usersRes.pagination);
      setLevel(me.adminLevel);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar utilizadores.");
    }
  }, [token, page, search, role]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleSuspend = async (id: string, suspended: boolean) => {
    if (!token || level !== "super-admin") return;
    const reason = window.prompt(suspended ? "Motivo da suspensão:" : "Motivo da reativação:") || "";
    if (!reason.trim()) return;
    setBusy(id);
    setError("");
    try {
      await authFetch(`/admin/users/${id}/suspend`, token, {
        method: "PATCH",
        body: JSON.stringify({ suspended, reason }),
      });
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Falha ao atualizar utilizador.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div>
      <AdminPageHeader
        eyebrow="Acessos"
        title="Gestão de Utilizadores"
        description="Monitorize perfis, papéis e estado de acesso com uma vista operacional clara."
        action={<span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-700">Permissões: {level}</span>}
      />

      <AdminFilterBar>
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Pesquisar por nome, email ou papel"
            className={`${adminFieldClass} md:col-span-2`}
          />
          <select value={role} onChange={(e) => { setRole(e.target.value); setPage(1); }} className={adminFieldClass}>
            <option value="all">Todos os papéis</option>
            <option value="candidate">Candidatos</option>
            <option value="company">Empresas</option>
            <option value="admin">Admins</option>
          </select>
      </AdminFilterBar>

      {error && <AdminAlert>{error}</AdminAlert>}

      <div className="mt-5 grid gap-3">
        {list.length === 0 && <AdminEmptyState title="Sem utilizadores nesta vista" description="Ajuste a pesquisa ou o filtro de papel." />}
        {list.map((userRecord) => {
          const state = userRecord.suspended ? "suspended" : "active";
          const adminInfo = userRecord.role === "admin" ? ` · ${userRecord.adminLevel || "super-admin"}` : "";
          return (
            <div key={userRecord._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold text-slate-900">{userRecord.fullName || "Utilizador"}</p>
                  <p className="text-sm text-slate-600">{userRecord.email || "Sem email"}</p>
                  <p className="text-xs text-slate-500">{userRecord.role || "role"}{adminInfo} · criado em {toDateLabel(userRecord.createdAt)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadgeClass(state)}`}>{state}</span>
                  <button
                    disabled={busy === userRecord._id || level !== "super-admin"}
                    onClick={() => toggleSuspend(userRecord._id, !userRecord.suspended)}
                    className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50"
                  >
                    {level !== "super-admin" ? "Apenas leitura" : userRecord.suspended ? "Reativar" : "Suspender"}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <PaginationControls pagination={pagination} onPage={setPage} />
    </div>
  );
}
