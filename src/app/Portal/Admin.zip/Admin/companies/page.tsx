"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { authFetch } from "@/lib/api";
import { fetchAdminMe, fetchCompanies, statusBadgeClass, toDateLabel, type CompanyRecord, type Pagination, type AdminLevel } from "../adminClient";
import { AdminAlert, AdminEmptyState, AdminFilterBar, AdminPageHeader, adminFieldClass } from "../components/AdminUI";
import PaginationControls from "../components/PaginationControls";

export default function AdminCompaniesPage() {
  const { token } = useAuth("admin");
  const [companies, setCompanies] = useState<CompanyRecord[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("pending");
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<Pagination | undefined>();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [level, setLevel] = useState<AdminLevel>("moderator");

  const load = useCallback(async () => {
    if (!token) return;
    setError("");
    try {
      const [res, me] = await Promise.all([
        fetchCompanies(token, { page, limit: 15, keyword: search, status: filter }),
        fetchAdminMe(token),
      ]);
      setCompanies(res.companies || []);
      setPagination(res.pagination);
      setLevel(me.adminLevel);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar empresas.");
    }
  }, [token, page, search, filter]);

  useEffect(() => {
    load();
  }, [load]);

  const verify = async (id: string, status: "verified" | "rejected" | "pending" | "needs_more_info" | "suspended") => {
    if (!token) return;
    if (status === "suspended" && level !== "super-admin") return;
    const reason = ["rejected", "needs_more_info", "suspended"].includes(status)
      ? (window.prompt("Motivo da decisão:") || "")
      : "";
    if (["rejected", "needs_more_info", "suspended"].includes(status) && !reason.trim()) return;
    setBusy(id);
    setError("");
    try {
      await authFetch(`/companies/${id}/verification`, token, {
        method: "PATCH",
        body: JSON.stringify({ status, reason }),
      });
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao atualizar empresa.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div>
      <AdminPageHeader
        eyebrow="Compliance"
        title="Verificação de Empresas"
        description="Aplique validação de reputação e conformidade de parceiros empregadores."
      />

      <AdminFilterBar>
        <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Pesquisar empresas" className={`${adminFieldClass} md:col-span-2`} />
        <select value={filter} onChange={(e) => { setFilter(e.target.value); setPage(1); }} className={adminFieldClass}>
          <option value="pending">Pendentes</option>
          <option value="verified">Verificadas</option>
          <option value="rejected">Rejeitadas</option>
          <option value="needs_more_info">Mais informação</option>
          <option value="suspended">Suspensas</option>
          <option value="all">Todas</option>
        </select>
      </AdminFilterBar>

      {error && <AdminAlert>{error}</AdminAlert>}

      <div className="mt-5 grid gap-3">
        {companies.length === 0 && <AdminEmptyState title="Sem empresas nesta vista" description="Ajuste os filtros ou aguarde novos registos de empresa." />}
        {companies.map((company) => {
          const status = String(company.verificationStatus || "pending");
          return (
            <div key={company._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-slate-900">{company.name || "Empresa"}</p>
                  <p className="text-xs text-slate-500">{company.industry || "Setor"} · {company.location || "Local"} · {company.contactEmail || "Sem email"}</p>
                  <p className="text-xs text-slate-400">{toDateLabel(company.createdAt)}</p>
                </div>
                <span className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadgeClass(status)}`}>{status}</span>
              </div>
              <div className="mt-3 flex gap-2">
                <button disabled={busy === company._id} onClick={() => verify(company._id, "verified")} className="rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Verificar</button>
                <button disabled={busy === company._id} onClick={() => verify(company._id, "rejected")} className="rounded-xl bg-rose-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Rejeitar</button>
                <button disabled={busy === company._id} onClick={() => verify(company._id, "needs_more_info")} className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-800 disabled:opacity-50">Pedir info</button>
                {level === "super-admin" && <button disabled={busy === company._id} onClick={() => verify(company._id, "suspended")} className="rounded-xl border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700 disabled:opacity-50">Suspender</button>}
                <button disabled={busy === company._id} onClick={() => verify(company._id, "pending")} className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50">Marcar pendente</button>
              </div>
            </div>
          );
        })}
      </div>
      <PaginationControls pagination={pagination} onPage={setPage} />
    </div>
  );
}
