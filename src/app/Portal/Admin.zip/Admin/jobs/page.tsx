"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { authFetch } from "@/lib/api";
import { fetchJobs, statusBadgeClass, toDateLabel, type JobRecord, type Pagination } from "../adminClient";
import { AdminAlert, AdminEmptyState, AdminFilterBar, AdminPageHeader, adminFieldClass } from "../components/AdminUI";
import PaginationControls from "../components/PaginationControls";

export default function AdminJobsPage() {
  const { token } = useAuth("admin");
  const [jobs, setJobs] = useState<JobRecord[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("pending");
  const [visibility, setVisibility] = useState("all");
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<Pagination | undefined>();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!token) return;
    setError("");
    try {
      const res = await fetchJobs(token, { page, limit: 15, keyword: search, status: filter, visibility });
      setJobs(res.jobs || []);
      setPagination(res.pagination);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar vagas.");
    }
  }, [token, page, search, filter, visibility]);

  useEffect(() => {
    load();
  }, [load]);

  const moderate = async (id: string, status: string, visibility?: string) => {
    if (!token) return;
    const reason = window.prompt("Nota de moderação (opcional):") || "";
    setBusy(id);
    setError("");
    try {
      await authFetch(`/admin/jobs/${id}/moderate`, token, {
        method: "PATCH",
        body: JSON.stringify({ status, visibility, reason }),
      });
      await load();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro na moderação da vaga.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div>
      <AdminPageHeader
        eyebrow="Moderação"
        title="Moderação de Vagas"
        description="Aprove, rejeite e arquive vagas com rastreabilidade operacional."
      />

      <AdminFilterBar>
        <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Pesquisar vagas" className={adminFieldClass} />
        <select value={filter} onChange={(e) => { setFilter(e.target.value); setPage(1); }} className={adminFieldClass}>
          <option value="pending_platform_review">Pendentes de plataforma</option>
          <option value="pending_company_approval">Pendentes internos (somente leitura)</option>
          <option value="approved">Aprovadas</option>
          <option value="published">Publicadas</option>
          <option value="platform_rejected">Rejeitadas</option>
          <option value="all">Todas</option>
        </select>
        <select value={visibility} onChange={(e) => { setVisibility(e.target.value); setPage(1); }} className={adminFieldClass}>
          <option value="all">Todas as visibilidades</option>
          <option value="public">Públicas</option>
          <option value="private">Privadas</option>
          <option value="draft">Rascunhos</option>
          <option value="archived">Arquivadas</option>
        </select>
      </AdminFilterBar>

      {error && <AdminAlert>{error}</AdminAlert>}

      <div className="mt-5 grid gap-3">
        {jobs.length === 0 && <AdminEmptyState title="Sem vagas nesta vista" description="Ajuste os filtros ou aguarde novas submissões." />}
        {jobs.map((job) => {
          const companyName = typeof job.companyId === "object" ? job.companyId?.name : "Empresa";
          const status = String(job.status || "pending");
          return (
            <div key={job._id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-slate-900">{job.title || "Vaga"}</p>
                  <p className="text-xs text-slate-500">{companyName || "Empresa"} · {job.location || "Local"} · {job.category || "Categoria"}</p>
                  <p className="text-xs text-slate-400">{toDateLabel(job.createdAt)}</p>
                </div>
                <span className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadgeClass(status)}`}>{status}</span>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <button disabled={busy === job._id} onClick={() => moderate(job._id, "published", "public")} className="rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Publicar</button>
                <button disabled={busy === job._id} onClick={() => moderate(job._id, "platform_rejected")} className="rounded-xl bg-rose-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50">Rejeitar</button>
                <button disabled={busy === job._id} onClick={() => moderate(job._id, status, "archived")} className="rounded-xl border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50">Arquivar</button>
              </div>
            </div>
          );
        })}
      </div>
      <PaginationControls pagination={pagination} onPage={setPage} />
    </div>
  );
}
