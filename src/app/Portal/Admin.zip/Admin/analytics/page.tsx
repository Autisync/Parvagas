"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { fetchAnalytics } from "../adminClient";
import { AdminAlert, AdminPageHeader, adminButtonClass, adminFieldClass } from "../components/AdminUI";

function toInputDate(daysAgo: number) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().slice(0, 10);
}

export default function AdminAnalyticsPage() {
  const { token } = useAuth("admin");
  const [from, setFrom] = useState(toInputDate(30));
  const [to, setTo] = useState(toInputDate(0));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [totals, setTotals] = useState({ users: 0, companies: 0, jobs: 0, scraped: 0, ads: 0 });
  const [operational, setOperational] = useState({ pendingJobs: 0, pendingCompanies: 0, suspendedUsers: 0, pendingScraped: 0 });

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const data = await fetchAnalytics(token, from, to);
      setTotals(data.totals);
      setOperational(data.operational);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erro ao carregar analytics.");
    } finally {
      setLoading(false);
    }
  }, [token, from, to]);

  useEffect(() => {
    load();
  }, [load]);

  const percentages = useMemo(
    () => ({
      pendingJobs: totals.jobs ? Math.round((operational.pendingJobs / totals.jobs) * 100) : 0,
      pendingCompanies: totals.companies ? Math.round((operational.pendingCompanies / totals.companies) * 100) : 0,
      suspendedUsers: totals.users ? Math.round((operational.suspendedUsers / totals.users) * 100) : 0,
      pendingScraped: totals.scraped ? Math.round((operational.pendingScraped / totals.scraped) * 100) : 0,
    }),
    [operational, totals]
  );

  return (
    <div>
      <AdminPageHeader
        eyebrow="Analytics"
        title="Analytics por Intervalo"
        description="KPIs dinâmicos por período para tomada de decisão operacional."
      />

      <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="grid gap-3 md:grid-cols-4">
          <label className="grid gap-1 text-sm">
            <span className="text-slate-600">Data inicial</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={adminFieldClass} />
          </label>
          <label className="grid gap-1 text-sm">
            <span className="text-slate-600">Data final</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={adminFieldClass} />
          </label>
          <div className="flex items-end">
            <button onClick={load} disabled={loading} className={adminButtonClass}>
              {loading ? "A calcular..." : "Atualizar KPIs"}
            </button>
          </div>
        </div>
        {error && <AdminAlert>{error}</AdminAlert>}
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {[
          { label: "Utilizadores", value: totals.users },
          { label: "Empresas", value: totals.companies },
          { label: "Vagas", value: totals.jobs },
          { label: "Scraped", value: totals.scraped },
          { label: "Ads", value: totals.ads },
        ].map((card) => (
          <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-xs uppercase tracking-wide text-slate-500">{card.label}</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">{card.value}</p>
          </div>
        ))}
      </section>

      <section className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Vagas pendentes", value: operational.pendingJobs, ratio: percentages.pendingJobs },
          { label: "Empresas pendentes", value: operational.pendingCompanies, ratio: percentages.pendingCompanies },
          { label: "Utilizadores suspensos", value: operational.suspendedUsers, ratio: percentages.suspendedUsers },
          { label: "Scraped pendente", value: operational.pendingScraped, ratio: percentages.pendingScraped },
        ].map((item) => (
          <div key={item.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-xs uppercase tracking-wide text-slate-500">{item.label}</p>
            <p className="mt-2 text-2xl font-bold text-slate-900">{item.value}</p>
            <p className="mt-1 text-xs text-slate-500">{item.ratio}% no intervalo selecionado</p>
          </div>
        ))}
      </section>
    </div>
  );
}
